#include<iostream>
using namespace std;

int main(){
    int a[3][3];
    cout<<"Enetr the array elements"<<endl;
    for(int i=0;i<=2;i++){
        for(int j=0;j<=2;j++){
            cin>>*(*(a+i)+j);
        }
    }
    cout<<"array elements are "<<endl;
    for(int i=0;i<=2;i++){
        for(int j=0;j<=2;j++){
            cout<<*(*(a+i)+j)<<"\t";
        }
        cout<<endl;
    }

}