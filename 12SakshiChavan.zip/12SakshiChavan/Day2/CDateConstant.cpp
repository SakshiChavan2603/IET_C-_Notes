#include<iostream>
using namespace std;

class CDate{
    int dd,mm,yy;
    public:
        CDate();
        CDate(int,int,int);
        void display() const;
        void setD(int);
        int getM() const;
};

CDate::CDate(){
    dd = 22;
    mm = 8;
    yy = 2025;
}

CDate::CDate(int d, int m, int y){
    dd = d;
    mm = m;
    yy = y;
}

void CDate::display() const{
    cout<<"Date is "<<dd<<"/"<<mm<<"/"<<yy<<endl;
}

void CDate::setD(int d){
    dd = d;
}

int CDate::getM() const{
    return mm;
}

int main(){
    //const CDate c();
    //c.display();
    const CDate c1(22,8,2025);
    c1.display();
    cout<<c1.getM()<<endl;
    CDate c(23,8,2025);
    c.setD(23);
    c.display();
    cout<<c.getM();
}