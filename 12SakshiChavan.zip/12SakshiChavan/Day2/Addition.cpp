#include<iostream>
using namespace std;
int main() {
    int n1, n2;
    cout<<"Enter No. 1 "<<endl;
    cin>>n1;
    cout<<"Enter No. 2 "<<endl;
    cin>>n2;
    cout<<"Sum = "<<n1+n1;
}