#include<iostream>
using namespace std;

class CDate{
    int dd,mm,yy;
    public:
        void accept();
        void dispaly();
        void setD(int);
        int getM();
};
void CDate::accept(){
    cout<<"Enetr the day month year\n";
    cin>>dd>>mm>>yy;
}
void CDate::dispaly(){
    cout<<"Date is "<<dd<<"/"<<mm<<"/"<<yy<<endl;
}

void CDate::setD(int d){
    dd = d;
}

int CDate::getM(){
    return mm;
}
int main(){
    CDate c1;
    c1.accept();
    c1.dispaly();
    c1.setD(23);
    c1.dispaly();
    cout<<c1.getM();
}