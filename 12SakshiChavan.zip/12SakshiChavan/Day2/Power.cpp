#include<iostream>
using namespace std;
int main() {
    int base, power, pow=1;
    cout<<"Enter Base "<<endl;
    cin>>base;
    cout<<"Enter Power "<<endl;
    cin>>power;
    for(int i = 1; i <= power; i++) {
        pow = pow * base;
    }
    cout<<"Power of "<<base<<"is "<<pow;

}