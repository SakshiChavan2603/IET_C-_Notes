#include<iostream>
using namespace std;
int main() {
    int a[5], i;
    cout<<"Enter the elements of an array: "<<endl;
    for(int i = 0; i <= 4; i++) {
        cin>>a[i];
    }
    cout<<"Display Elements: "<<endl;
    for(i = 0; i <= 4; i++) {
        cout<<a[i]<<"\t";
    }

}