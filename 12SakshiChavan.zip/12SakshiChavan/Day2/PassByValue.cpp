#include<iostream>
using namespace std;

void swap(int, int);

int main(){
    int a=10, b=20;
    cout<<"before swapping"<<endl;
    cout<<a<<" "<<b<<endl;
    swap(a,b);
    cout<<"After swapping"<<endl;
    cout<<a<<" "<<b<<endl;
}
void swap(int p, int q){
    int temp;
    temp = p;
    p = q;
    q = temp;
    cout<<"In swap function"<<endl;
    cout<<p<<" "<<q<<endl;
}