#include <iostream>
using namespace std;

int main() {
    float principal, rate, time, n, amount = 1, base;
    int exponent;

    cout<<"Enter the principal amount: ";
    cin>>principal;
    cout<<"Enter the annual interest rate : ";
    cin>>rate;
    cout<<"Enter the time : ";
    cin>>time;
    cout<<"Enter the number of times interest is compounded per year: ";
    cin>>n;

    rate = rate / 100; 
    base = (1 + rate / n);
    exponent = n * time;
    cout<<exponent;

    for (int i = 0; i < exponent; i++) {
        amount = amount * base; 
    }

    amount = amount * principal;
    float compoundInterest = amount - principal;

    cout<<"Total Amount:\n"<<amount;
    cout<<"Compound Interest:\n"<<compoundInterest;

    return 0;
}