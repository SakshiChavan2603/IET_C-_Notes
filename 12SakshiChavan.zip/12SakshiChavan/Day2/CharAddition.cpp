#include<iostream>
using namespace std;

int main(){
    char a, b;
    cout<<"Enetr the the two character\n";
    cin>>a>>b;
    cout<<char(a+b);
}