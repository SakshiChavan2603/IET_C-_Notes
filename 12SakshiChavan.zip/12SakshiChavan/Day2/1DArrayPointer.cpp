#include<iostream>
using namespace std;
int main() {
    int a[5];
    cout<<"Enter the array elements "<<endl;
    for(int i = 0; i <= 4;i++) {
        cin>>*(a + i);
    }
    cout<<"Elements are "<<endl;
    for(int i = 0; i <= 4; i++) {
        cout<<*(a + i)<<"\t";
    }
}