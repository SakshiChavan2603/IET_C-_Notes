#include<iostream>
using namespace std;
void swap(int &, int &);

int main(){
    int a = 10, b=20;
    cout<<"Before Swapping\n";
    cout<<a<<" "<<b<<endl;
    swap(a,b);
    cout<<"After Swapping\n";
    cout<<a<<" "<<b<<endl;
}

void swap(int &p, int &q){
    int temp;
    temp = p;
    p = q;
    q = temp;
    cout<<"In Swap Function\n";
    cout<<p<<" "<<q<<endl;
}