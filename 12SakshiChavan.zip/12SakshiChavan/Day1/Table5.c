#include<stdio.h>

int main(){
	int no;
	printf("Enetr the no for table calculation");
	scanf("%d ",&no);
	int i;
	for(i=1;i<=10;i++){
		//printf("%d",i);
		printf("%d * %d = %d\n",no,i,no*i);
	}
}
