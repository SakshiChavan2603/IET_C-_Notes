//addition of even and odd between 1 to 20

#include<stdio.h>

int main(){
	int even_sum =0,odd_sum=0;
	int i;
	for(i =1;i<=20;i++){
		if(i%2==0){
			even_sum = even_sum+i;
		}else{
			odd_sum = odd_sum+i;
		}
	}
	printf("%d %d",even_sum+odd_sum);
}
