#include<stdio.h>
int main(){
	int no;
	printf("Enetr the no for factorial\n");
	scanf("%d",&no);
	
	int fact = 1, i;
	for(i=1;i<=no;i++){
		fact = fact * i;
	}
	printf("Factorial of %d is %d",no,fact);
}
