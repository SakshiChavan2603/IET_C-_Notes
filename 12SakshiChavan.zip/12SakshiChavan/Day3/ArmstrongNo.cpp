#include<iostream>
using namespace std;

int main(){
    int no;
    cout<<"enter the number"<<endl;
    cin>>no;

    int original = no;
    int sum =0;
    while(no!=0){
        int rem = no%10;
        sum = sum + rem*rem*rem;
        no = no/10;
    }
    cout<<no<<endl;
    if(original == sum){
        cout<<original<<" is armstrong number"<<endl;
    }else{
        cout<<original<<" is not armstrong number"<<endl;
    }
}