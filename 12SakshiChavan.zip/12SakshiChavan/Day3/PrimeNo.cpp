#include<iostream>
using namespace std;

int main(){
    int num;
    cout<<"enetr the no\n";
    cin>>num;

    int count = 0;
    for(int i =2;i<num;i++){
        if(num%i==0){
            count++;
        }
    }
    if(count >= 1) {
        cout<<"The number is not prime number"<<endl;
    } else {
        cout<<"The number is prime number"<<endl;
    }

}