#include<iostream>
using namespace std;
void string_copy(char*, char*);
int main(){
    char str1[20]="Sakshi";
    char str2[50];
    cout<<str1<<endl;
    string_copy(str2,str1);
    cout<<str2;
}

void string_copy(char *s2,char *s1){
    while(*s1!='\0'){
        *s2=*s1;
        s1++;
        s2++;
    }
    *s2='\0';
}