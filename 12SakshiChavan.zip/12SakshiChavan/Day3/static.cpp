#include<iostream>
using namespace std;

static int i;
static int j = 12;
int main(){
    static int j = 11;
    cout<<i<<endl;
    //cout<<i<<endl;;
    cout<<j;
}