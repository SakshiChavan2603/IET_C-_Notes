#include<string.h>
#include<iostream>
using namespace std;
void stringlength(char*);
int main(){
    char str[50];
    cout<<"enetr the string\n";
    cin>>str;
    //cout<<"Length of "<<str<<" is "<<strlen(str)<<endl;
    //cout<<"size of "<<str<<" is "<<sizeof(str)<<endl;
    stringlength(str);
}

void stringlength(char* s){
    int count = 0;
    while(*s!='\0'){
        count++;
        s++;
    }
    cout<<"Length of string is "<<count<<endl;
}