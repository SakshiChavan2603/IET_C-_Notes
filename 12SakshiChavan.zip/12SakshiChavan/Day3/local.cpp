#include<iostream>
using namespace std;

int main(){
    int i;
    cout<<i<<endl; // default value garbage
    int j =0;
    cout<<j<<endl;
}