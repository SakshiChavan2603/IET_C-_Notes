#include<iostream>
using namespace std;
void show();
int x = 10;
int main(){
    cout<<x<<endl;
    x++;
    show();
    cout<<x<<endl;
}

void show(){
    cout<<x<<endl;
    int y =0;
    cout<<y<<endl;
    y++;
    cout<<y<<endl;
}