/*you can not declarre constructor as a constant 
because const has property that you can not reassign the value*/

#include<iostream>
using namespace std;

class Student{
    int rollno;
    public:
        Student(){
            rollno = 1;
        }

        void display(){
            cout<<"Roll no is "<<rollno;
        }
};

int main(){
    Student s;
    s.display();
}