#include<iostream>
using namespace std;
class Test{
    static int count1;
    static int count2;
    public:
        static int getCount(){
            return count1;
        }
        Test(){
            cout<<"object is created "<<count1<<endl;
            count1++;
            cout<<this<<endl;
        }
        ~Test(){
            cout<<"object is destroyed "<<count2<<endl;
            ++count2;
            cout<<this<<endl;            
        }
};

int Test::count1 = 1;
int Test::count2 = 1;

int main(){
    Test t1;
    cout<<&t1<<endl;
    Test t2;
    cout<<&t2;
    cout<<"Count is "<<Test::getCount();
}