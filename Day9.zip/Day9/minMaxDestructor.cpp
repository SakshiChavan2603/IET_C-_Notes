#include<iostream>
using namespace std;

class Temp{
    int *ptr;
    int size;
    public:
        Temp();
        void get();
        void show();
        int Min();
        int Max();
        ~Temp(){
            cout<<"Destructor is called\n";
            delete [] ptr;
        }
};
Temp::Temp(){
    cout<<"enetr the size\n";
    cin>>size;
    ptr=new int[size];
}
void Temp::get(){
    cout<<"Enetr the elements\n";
    for(int i=0;i<size;i++){
        cin>>ptr[i];
    }
}
void Temp::show(){
    cout<<"display the elements\n";
    for(int i=0;i<size;i++){
        cout<<ptr[i]<<"\t";
    }
}
int Temp::Max(){
    int maxx =ptr[0];
    for(int i=1;i<size;i++){
        if(maxx<ptr[i]){
            maxx = ptr[i];
        }
    }
    return maxx;
}

int Temp::Min(){
    int minn = ptr[0];
    for(int i=0;i<size;i++){
        if(minn>ptr[i]){
            minn = ptr[i];
        }
    }
    return minn;
}

int main(){
    Temp t;
    t.get();
    t.show();
    cout<<"\nMaximum is "<<t.Max()<<endl;
    cout<<"Minimum is "<<t.Min()<<endl;
}