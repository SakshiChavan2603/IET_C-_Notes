#include<iostream>
using namespace std;

class Test{
    int a;

    public:
        void init(int i){
            a = i;
        }
        void display(){
            cout<<"value of a is "<<a<<endl;
        }
};

int main(){
    Test t;
    t.init(19);
    t.display();
    //implicit copy constructor calling
    Test t1(t);
    t1.display();
}