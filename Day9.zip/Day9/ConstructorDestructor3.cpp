#include<iostream>
using namespace std;
static int count = 0;
class Test{
    public:
        Test(){
            count++;
            //cout<<"Constructor is called"<<endl;
            cout<<"object is created "<<count<<endl;
        }
        ~Test(){
            //cout<<"Destructor is called \n";
            cout<<"object is destroyed "<<count<<endl;
            count--;
            
        }
};
int main(){
    Test t1,t2,t3,t4;
    cout<<"t1"<<&t1<<endl;
    cout<<"t2"<<&t2<<endl;
    cout<<"t3"<<&t3<<endl;
    cout<<"t4"<<&t4<<endl;
}