#include <iostream>
#include <string.h>
using namespace std;

class string1 {
    char *ptr;
    int len;
    public:
        string1(char * sptr) {
            len = strlen(sptr);
            ptr = new char[len+1];
            strcpy(ptr, sptr);
        }

        void display() {
            cout<<"String is "<<ptr<<endl;
            cout<<"String length is "<<len<<endl;
        }

        string1(string1& c) {
            this->len = c.len;
            this->ptr = new char[this->len+1];
            strcpy(this->ptr,c.ptr);
        }

        ~string1() {
            if(ptr) {
                cout<<"Destructor is called "<<endl;
                delete [] ptr;
            } else {
                cout<<"Destructor is called "<<endl;
            }
        }
};

int main() {
    string1 s("sakshi");
    s.display();
    string1 s1(s);
    s1.display();

}