#include<iostream>
using namespace std;

class Test{
    public:
        Test(){
            cout<<"Constructor is called"<<endl;
        }
        ~Test(){
            cout<<"Destructor is called \n";
        }
};
int main(){
    Test t1,t2,t3,t4;
}