#include<iostream>
using namespace std;

class Date {
    int dd, mm, yy;
    public:
        Date(int, int, int);
        void show();
        Date(Date&);
};
Date::Date(int d, int m, int y) {
    dd = d;
    mm = m;
    yy = y;
}

void Date::show() {
    cout<<dd<<"/"<<mm<<"/"<<yy<<endl;
}

Date::Date(Date & Date_new) {
    this->dd = Date_new.dd;
    this->mm = Date_new.mm;
    this->yy = 2026;
}

int main() {
    Date d1(2,3,2025);
    cout<<&d1<<endl;
    d1.show();
    Date d2(d1);
    cout<<&d2<<endl;
    d2.show();


}