#include<iostream>
#include<string.h>
using namespace std;

class String1{
    char *s;
    int size;
    public:
        String1(char *c){
            size = strlen(s);
            s = new char[size+1];
            strcpy(s,c);
            cout<<s<<endl;
        }
        ~String1(){
            cout<<"des called\n";
            cout<<s;
            delete [] s;
            cout<<s;
        }

};

int main(){
    String1 s("Hello, Sakshi");
}