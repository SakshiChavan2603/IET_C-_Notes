#include <iostream>
#include <math.h>
using namespace std;

int main() {
    //Square Root
    int i = 36;
    cout<<"Square Root of "<<i<<" is "<<sqrt(i)<<endl;

    //Power
    int base = 2, expo = 3;
    cout<<"Power "<<expo<<" to the base "<<base<<" is "<<pow(base, expo)<<endl;

    //Ceil
    float num = 10.6;
    cout<<"Ceil of "<<num<<" is "<<ceil(num)<<endl;

    float num5 = -10.6;
    cout<<"Ceil of "<<num5<<" is "<<ceil(num5)<<endl;

    //floor
    float num1 = 10.6;
    cout<<"Floor of "<<num1<<" is "<<floor(num1)<<endl;

    float num6 = -10.6;
    cout<<"Floor of "<<num6<<" is "<<floor(num6)<<endl;

    //Round off
    float num2 = 10.4;
    cout<<"Round off of "<<num2<<" is "<<round(num2)<<endl;

    float num3 = 10.6;
    cout<<"Round off of "<<num3<<" is "<<round(num3)<<endl;

    float num4 = -10.4;
    cout<<"Round off of "<<num4<<" is "<<round(num4)<<endl;

    //Absolute
    int abss = -10;
    cout<<"Absolute value of "<<abss<<" is "<<abs(abss)<<endl;

    int abss1 = 10;
    cout<<"Absolute value of "<<abss1<<" is "<<abs(abss1)<<endl;
}