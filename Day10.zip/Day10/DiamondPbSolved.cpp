
/* 
 When virtual keyword write in front of grandparent class it implicitly calls the default constructor of grandparent class. If you don't mension in the child class which constructor you want to call.
*/

#include <iostream>
using namespace std;

class Person {
    public:
        Person() {
            cout<<"Person::Person() called"<<endl;
        }
        Person(int x) {
            cout<<"Person::Person(int x) called"<<endl;
        }
};

class Student: virtual public Person {
    public:
        Student(int x):Person(x) {
            cout<<"Student::Student(int x) called"<<endl;
        }
};

class Faculty: virtual public Person {
    public:
        Faculty(int x):Person(x) {
            cout<<"Faculty::Faculty(int x) called"<<endl;
        }
};

class child: public Student, public Faculty {
    public:
        child(int x):Student(x), Faculty(x) {
            cout<<"child::child(int x) called"<<endl;
        }
};

int main() {
    child obj(3);
}

