#include <iostream>
using namespace std;

class Person {
    public:
        Person(int x) {
            cout<<"Person::Person(int x) called"<<endl;
        }
};

class Student: public Person {
    public:
        Student(int x):Person(x) {
            cout<<"Student::Student(int x) called"<<endl;
        }
};

class Faculty: public Person {
    public:
        Faculty(int x):Person(x) {
            cout<<"Faculty::Faculty(int x) called"<<endl;
        }
};

class child: public Student, public Faculty {
    public:
        child(int x):Student(x), Faculty(x) {
            cout<<"child::child(int x) called"<<endl;
        }
};

int main() {
    child obj(3);
}

