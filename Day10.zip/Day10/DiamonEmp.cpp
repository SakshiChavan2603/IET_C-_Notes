#include<iostream>
using namespace std;

class Employee{
    int id;
    public:
        Employee(){
            cout<<"Employee::Employee() called"<<endl;
        }
        Employee(int x){
            cout<<"Employee::Employee(int x) called"<<endl;
        }
        void display(){
            cout<<"id is "<<id<<endl;
        }
};

class Manager:virtual public Employee{
    public:
        Manager(int x):Employee(x){
            cout<<"Manager::Manager(int x) called"<<endl;
        }
        void petrolAllow(){

        }
        void foodAllow(){

        }
};

class SalesPerson:virtual public Employee{
    int sales,comm;
    public:
        SalesPerson(int x):Employee(x){
            cout<<"SlesPerson::SalesPerson(int x) called"<<endl;
        }
};

class salesManager:public Manager,public SalesPerson{
    public:
        salesManager(int x):Manager(x),SalesPerson(x),Employee(x) {
            cout<<"salesManager::salesManager(int x) called"<<endl;
        }
};

int main(){
    salesManager s(10);
    s.display();
}
