#include<iostream>
using namespace std;

template<class T>
void fun(T a, T b){
    cout<<"a "<<a<<endl;
    cout<<"b "<<b<<endl;
}

template<class T1, class T2>
void fun(T1 a, T2 b){
    cout<<"a "<<a<<endl;
    cout<<"b "<<b<<endl;
}

template<class T1, class T2, class T3>
void fun(T1 a, T2 b, T3 c){
    cout<<"a "<<a<<endl;
    cout<<"b "<<b<<endl;
    cout<<"c "<<c<<endl;
}

int main(){
    fun(10,20);
    fun(10,10.2);
    fun(10,10.2,'c');
    fun(10,10,10);
}