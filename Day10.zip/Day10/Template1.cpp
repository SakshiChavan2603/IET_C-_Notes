#include<iostream>
using namespace std;

template<class T>
void fun(T a){
    cout<<a<<endl;
}

template<class T, class T1>
void fun(T b, T1 c){
    cout<<"b "<<b<<endl;
    cout<<"c "<<c<<endl;
}

int main(){
    fun(10);
    fun(10,10.2);
    fun('s',"sakshi");
}