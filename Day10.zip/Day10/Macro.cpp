#include <iostream>
using namespace std;

#define MAXIMUM(a, b) (a>b) ? a : b;

int main() {
    cout<<"Max of (100, 1000) : "<<endl;
    int k = MAXIMUM(100, 1000);
    cout<<k<<endl;
    
}