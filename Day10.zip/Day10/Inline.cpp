#include <iostream>
using namespace std;

inline void cube(int a) {
    cout<<"Cube of "<<a<<" is "<<a * a * a<<endl;
}

int main() {
    cube(10);
    
}