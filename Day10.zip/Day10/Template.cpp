#include<iostream>
using namespace std;

template<class T, class T1>
T1 add(T &i, T1 &j){
    T1 result = i+j;
    return result;
}

int main(){
    int i=1;
    int j=2;
    float a=1.1;
    float b=2.2;
    cout<<add(i,j)<<endl;
    cout<<add(a,b)<<endl;
    cout<<add(i,a)<<endl;
    cout<<add(b,j);
    
}