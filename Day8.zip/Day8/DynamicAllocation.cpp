#include<iostream>
using namespace std;

class Demo {
    int *ptr;
    public:
    Demo() {
        ptr = new int;
        *ptr = 10;
    }

    void display() {
        cout<<"Ptr = "<<*ptr<<endl;
    }

    ~Demo(){
        cout<<"destructor\n";
        delete ptr;
    }
};

int main() {
    Demo d;
    d.display();
    
}