#include<iostream>
using namespace std;

class Complex{
    int real, img;
    public:
        Complex();
        Complex(int,int);
        void display();
        Complex operator+(Complex &);
        Complex operator-(Complex &);
        Complex operator-();
        Complex operator++(int);
        Complex operator++();
};
Complex::Complex(){
    real = img = 0;
}
Complex::Complex(int real, int img){
    this->real = real;
    this->img = img;
}
void Complex::display(){
    if(img>0)
    cout<<real <<" + "<<img<<"i"<<endl;
    else
    cout<<real<<" "<<img<<"i"<<endl;
}
Complex Complex::operator+(Complex & c2_new){
    Complex temp;
    temp.real = this->real+c2_new.real;
    temp.img = this->img+c2_new.img;
    return temp; 

}
Complex Complex::operator-(Complex &new_c2){
    Complex temp;
    temp.real = this->real - new_c2.real;
    temp.img = img - new_c2.img;
    return temp;
}
Complex Complex::operator-(){
    Complex temp;
    temp.real = -real;
    temp.img = -img;
    return temp;
}
Complex Complex::operator++(int){
    Complex temp = (*this);
    this->real = this->real+1;
    this->img = this->img+1;
    return temp;
}
Complex Complex::operator++(){
    this->real = this->real+1;
    this->img = this->img+1;
    return (*this);
}
int main(){
    Complex c1(1,2);
    //Complex c2(3,4);
    //Complex c3;
    // c3 = c1+c2; // c3 = c1.operator+(c2);
    // c3.display();
    // Complex c4 = c1-c2; // c4 = c1.operator-(c2);
    // c4.display();
    // Complex c5 = -c1; // c5 = c1.operator-();
    // c5.display();
    Complex c6(1,2);
    Complex c7 = c6++; // c7 = c6.operator++(int);
    c6.display();
    c7.display();
    Complex c8(2,3);
    Complex c9 = ++c8; // c9 = c8.operator++();
    c8.display();
    c9.display();
}