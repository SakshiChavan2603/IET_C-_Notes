#include<iostream>
#include<string.h>
using namespace std;
class String1{
    int len;
    char *ptr;
    public:
        String1();
        String1(char*);
        String1(char , int);
        String1(int);
        void display();
};
String1::String1(){
    len =1;
    ptr = new char;
    *ptr = 'S';
}
void String1::display(){
    if(len>1){
        cout<<"String is "<<ptr<<endl;
        cout<<"Length of string is "<<len<<endl;
    }else{
        cout<<"Character is "<<*ptr<<endl;
        cout<<"Length of character is "<<len<<endl;
    }
}
String1::String1(char * s){
    len = strlen(s);
    ptr=new char[len+1];
    strcpy(ptr,s);
}
String1::String1(char c, int len){
    this->len = len;
    ptr = new char[len+1];
    for(int i=0;i<len;i++){
        ptr[i]=c;
    }
    ptr[len]='\0';
}
String1::String1(int len){
    this->len = len;
    ptr = new char[len+1];
    cout<<"Enter the string"<<endl;
    cin>>ptr;
}
int main(){
    String1 s1;
    s1.display();
    String1 s2("Sakshi");
    s2.display();
    String1 s3('*',80);
    s3.display();
    String1 s4(4);
    s4.display();
}