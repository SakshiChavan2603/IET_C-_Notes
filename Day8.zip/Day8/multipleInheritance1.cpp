#include<iostream>
using namespace std;

class A {
    int i;
    public:
    A() {
        cout<<"In default of A "<<endl;
    }
    A(int i) {
        this->i = i;
        cout<<"In para of A "<<endl;
    }
};

class B {
    int j;
    public:
    B() {
        cout<<"In default of B "<<endl;
    }
    B(int j) {
        this->j = j;
        cout<<"In para of B "<<endl;
    }
};

class C: public A, public B {
    int i, j;
    public:
    C() {
        cout<<"In default of C "<<endl;
    }
    C(int i, int j):A(i), B(j) {
        this->i = i;
        this->j = j;
        cout<<"In para of C "<<endl;
    }
};

int main() {
    C c(1,2);


}