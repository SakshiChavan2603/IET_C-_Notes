#include<iostream>
using namespace std;

class A {
    public:
    void show() {
        cout<<"in show of A"<<endl;
    }
};

class B {
    public:
    void show() {
        cout<<"in show of B"<<endl;
    }
};

class C:public B, public A {
    public:
    void display() {
        cout<<"in display of C"<<endl;
    }
};

int main() {
    C c;
    c.display();
    //c.show(); // It is giving error because their is ambiguity to chose which show() function to call. 
    c.A::show();
    c.B::show();
    
}